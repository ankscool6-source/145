// Populate the year
document.getElementById('year').textContent = new Date().getFullYear();

// Build a simple gallery & marquee from available assets
const assets = [];
for(let i=0;i<200;i++){
  const exts = ['.png','.jpg','.jpeg','.gif','.webp','.svg'];
  for(const ext of exts){
    const path = `assets/img_${i}${ext}`;
    assets.push(path);
  }
}

function preload(url, cb){ const img = new Image(); img.onload = cb; img.onerror = cb; img.src = url; }

const gallery = document.getElementById('gallery');
const marquee = document.getElementById('marquee');

let count = 0;
assets.forEach(src => {
  const ext = src.split('.').pop();
  // only include likely existing assets
  fetch(src, {method:'HEAD'}).then(r => {
    if(r.ok){
      // gallery tiles
      if(count < 9){
        const tile = document.createElement('article');
        tile.className = 'tile';
        tile.innerHTML = `<img src="${src}" alt=""><div class="tile-body"><h4>Project ${count+1}</h4><p>Packaging • Print</p></div>`;
        gallery.appendChild(tile);
      }
      // marquee images
      const img = document.createElement('img');
      img.src = src;
      img.alt = '';
      marquee.appendChild(img.cloneNode());
      marquee.appendChild(img.cloneNode());
      count++;
    }
  }).catch(()=>{});
});

// Mobile nav
const navToggle = document.getElementById('navToggle');
const navLinks = document.querySelector('.nav-links');
navToggle?.addEventListener('click', () => {
  const isOpen = navLinks.style.display === 'flex';
  navLinks.style.display = isOpen ? 'none' : 'flex';
  navLinks.style.flexDirection = 'column';
  navLinks.style.gap = '12px';
});

// Fake form submission
const form = document.getElementById('quoteForm');
const statusEl = document.getElementById('formStatus');
form?.addEventListener('submit', (e) => {
  e.preventDefault();
  statusEl.textContent = 'Thanks! We will get back to you within 1 business day.';
  form.reset();
});
